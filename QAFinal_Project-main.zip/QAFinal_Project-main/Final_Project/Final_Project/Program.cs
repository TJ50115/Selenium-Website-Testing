﻿using MySql.Data.MySqlClient;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Org.BouncyCastle.Security;
using Bogus;
using Final_Project;
class Program
{
    public static MySqlConnection? connection;
    static void Main(string[] args)
    {
        SiteReset();
        bool REG01 = false;
        bool REG02 = false;
        bool REG03 = false;
        bool REG04 = false;
        bool REG05 = false;
        bool REG06 = false;
        bool REG07 = false;
        bool REG08 = false;
        bool REG09 = false;
        bool REG10 = false;
        bool REG11 = false;
        bool BP01 = false;
        bool BP02 = false;
        bool BP03 = false;
        bool BP04 = false;
        bool BP05 = false;
        bool LOG01 = false;
        bool LOG02 = false;
        bool LOG03 = false;
        bool LOG04 = false;
        bool LOG05 = false;
        bool LOG06 = false;
        bool LOG07 = false;
        //REG01
        IWebDriver driver = new ChromeDriver(@"C:\Selenium");
        driver.Url = "http://10.157.123.12/site1/login.php";
        REG01 = SiteTest.REG01(driver);
        driver.Quit();

        //REG02
        IWebDriver driver2 = new ChromeDriver(@"C:\Selenium");
        driver2.Url = "http://10.157.123.12/site1/signup.php";
        REG02 = SiteTest.REG02(driver2);
        driver2.Quit();

        //REG03
        IWebDriver driver3 = new ChromeDriver(@"C:\Selenium");
        driver3.Url = "http://10.157.123.12/site1/signup.php";
        REG03 = SiteTest.REG03(driver3);
        driver3.Quit();

        //REG04
        IWebDriver driver4 = new ChromeDriver(@"C:\Selenium");
        driver4.Url = "http://10.157.123.12/site1/signup.php";
        REG04 = SiteTest.REG04(driver4);
        driver4.Quit();

        //REG05
        IWebDriver driver5 = new ChromeDriver(@"C:\Selenium");
        driver5.Url = "http://10.157.123.12/site1/signup.php";
        REG05 = SiteTest.REG05(driver5);
        driver5.Quit();

        //REG06
        IWebDriver driver6 = new ChromeDriver(@"C:\Selenium");
        driver6.Url = "http://10.157.123.12/site1/signup.php";
        REG06 = SiteTest.REG06(driver6);
        driver6.Quit();

        //REG07
        IWebDriver driver7 = new ChromeDriver(@"C:\Selenium");
        driver7.Url = "http://10.157.123.12/site1/signup.php";
        REG07 = SiteTest.REG07(driver7);
        driver7.Quit();

        //REG08
        IWebDriver driver8 = new ChromeDriver(@"C:\Selenium");
        driver8.Url = "http://10.157.123.12/site1/signup.php";
        REG08 = SiteTest.REG08(driver8);
        driver8.Quit();

        //REG09
        IWebDriver driver9 = new ChromeDriver(@"C:\Selenium");
        driver9.Url = "http://10.157.123.12/site1/signup.php";
        REG09 = SiteTest.REG09(driver9);
        driver9.Quit();


        //REG10
        IWebDriver driver10 = new ChromeDriver(@"C:\Selenium");
        driver10.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        driver10.Url = "http://10.157.123.12/site1/signup.php";
        REG10 = SiteTest.REG10(driver10);
        driver10.Quit();

        //REG11
        IWebDriver driver11 = new ChromeDriver(@"C:\Selenium");
        driver11.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        driver11.Url = "http://10.157.123.12/site1/signup.php";
        REG11 = SiteTest.REG11(driver11);
        driver11.Quit();

        //BP01
        IWebDriver driver12 = new ChromeDriver(@"C:\Selenium");
        driver12.Url = "http://10.157.123.12/site1/login.php";
        driver12.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        BP01 = SiteTest.BP01(driver12);
        driver12.Quit();

        //BP02
        IWebDriver driver13 = new ChromeDriver(@"C:\Selenium");
        driver13.Url = "http://10.157.123.12/site1/login.php";
        driver13.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        BP02 = SiteTest.BP02(driver13);
        driver13.Quit();

        //BP03
        IWebDriver driver14 = new ChromeDriver(@"C:\Selenium");
        driver14.Url = "http://10.157.123.12/site1/login.php";
        driver14.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        BP03 = SiteTest.BP03(driver14);
        driver14.Quit();

        //BP04
        IWebDriver driver15 = new ChromeDriver(@"C:\Selenium");
        driver15.Url = "http://10.157.123.12/site1/login.php";
        driver15.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        BP04 = SiteTest.BP04(driver15);
        driver15.Quit();

        //BP05
        IWebDriver driver16 = new ChromeDriver(@"C:\Selenium");
        driver16.Url = "http://10.157.123.12/site1/login.php";
        driver16.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        BP05 = SiteTest.BP05(driver16);
        driver16.Quit();

        //LOG01
        IWebDriver logdriver = new ChromeDriver(@"C:\Selenium");
        logdriver.Url = "http://10.157.123.12/site1/login.php";
        LOG01 = SiteTest.LOG01(logdriver);
        logdriver.Quit();

        //LOG02
        IWebDriver logdriver2 = new ChromeDriver(@"C:\Selenium");
        logdriver2.Url = "http://10.157.123.12/site1/login.php";
        LOG02 = SiteTest.LOG02(logdriver2);
        logdriver2.Quit();

        //LOG03
        IWebDriver logdriver3 = new ChromeDriver(@"C:\Selenium");
        logdriver3.Url = "http://10.157.123.12/site1/login.php";
        LOG03 = SiteTest.LOG03(logdriver3);
        logdriver3.Quit();

        //LOG04
        IWebDriver logdriver4 = new ChromeDriver(@"C:\Selenium");
        logdriver4.Url = "http://10.157.123.12/site1/login.php";
        LOG04 = SiteTest.LOG04(logdriver4);
        logdriver4.Quit();

        //LOG05
        IWebDriver logdriver5 = new ChromeDriver(@"C:\Selenium");
        logdriver5.Url = "http://10.157.123.12/site1/login.php";
        LOG05 = SiteTest.LOG05(logdriver5);
        logdriver5.Quit();

        //LOG06
        IWebDriver logDriver6 = new ChromeDriver(@"C:\Selenium");
        logDriver6.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        logDriver6.Url = "http://10.157.123.12/site1/login.php";
        LOG06 = SiteTest.LOG06(logDriver6);
        logDriver6.Quit();

        //LOG07
        IWebDriver logDriver7 = new ChromeDriver(@"C:\Selenium");
        logDriver7.Manage().Window.Size = new System.Drawing.Size(1200, 800);
        logDriver7.Url = "http://10.157.123.12/site1/login.php";
        LOG07 = SiteTest.LOG07(logDriver7);
        logDriver7.Quit();

        Console.WriteLine(
            $"REG01: {REG01}\r\n" +
            $"REG02: {REG02}\r\n" +
            $"REG03: {REG03}\r\n" +
            $"REG04: {REG04} \r\n" +
            $"REG05: {REG05}\r\n" +
            $"REG06: {REG06} \r\n" +
            $"REG07: {REG07} \r\n" +
            $"REG08: {REG08} \r\n" +
            $"REG09: {REG09} \r\n" +
            $"REG10: {REG10} \r\n" +
            $"REG11: {REG11} \r\n" +
            $"BP01: {BP01}\r\n" +
            $"BP02: {BP02} \r\n" +
            $"BP03: {BP03} \r\n" +
            $"BP04: {BP04} \r\n" +
            $"BP05: {BP05} \r\n" +
            $"LOG01: {LOG01} \r\n" +
            $"LOG02: {LOG02}\r\n" +
            $"LOG03: {LOG03}\r\n" +
            $"LOG04: {LOG04}\r\n" +
            $"LOG05: {LOG05}\r\n" +
            $"LOG06: {LOG06}\r\n" +
            $"LOG07: {LOG07}");
    }

    public static void SiteReset()
    {
        string myConnectionString = "server=10.157.123.12;database=bitter-site1;uid=site1;pwd=ASMfoo34b3CdZoss;";
        connection = new MySqlConnection(myConnectionString);
        MySqlCommand command = new MySqlCommand();
        command.Connection = connection;
        command.CommandText = "reset";
        command.CommandType = System.Data.CommandType.StoredProcedure;
        connection.Open();
        command.ExecuteNonQuery();
        connection.Close();
    }

}
