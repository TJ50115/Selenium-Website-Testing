﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
namespace Final_Project
{
    public class SiteWebElements
    {
        public static IWebElement SignUpButton(IWebDriver driver)
        {
            return driver.FindElement(By.CssSelector("a[href='signup.php']"));
        }
        public static IWebElement SignUpFName(IWebDriver driver)
        {
            return driver.FindElement(By.Id("firstname"));
        }
        public static IWebElement SignUpLName(IWebDriver driver)
        {
            return driver.FindElement(By.Id("lastname"));
        }
        public static IWebElement SignUpEmail(IWebDriver driver)
        {
            return driver.FindElement(By.Id("email"));
        }
        public static IWebElement SignUpScreenName(IWebDriver driver)
        {
            return driver.FindElement(By.Id("username"));
        }
        public static IWebElement SignUpPassword(IWebDriver driver)
        {
            return driver.FindElement(By.Id("password"));
        }
        public static IWebElement SignUpConfPass(IWebDriver driver)
        {
            return driver.FindElement(By.Id("confirm"));
        }
        public static IWebElement SignUpPhoneNum(IWebDriver driver)
        {
            return driver.FindElement(By.Id("phone"));
        }
        public static IWebElement SignUpAddress(IWebDriver driver)
        {
            return driver.FindElement(By.Id("address"));
        }
        public static IWebElement SignUpProvince(IWebDriver driver)
        {
            return driver.FindElement(By.Id("province"));
        }
        public static IWebElement SignUpPostal(IWebDriver driver)
        {
            return driver.FindElement(By.Id("postalCode"));
        }
        public static IWebElement SignUpUrl(IWebDriver driver)
        {
            return driver.FindElement(By.Id("url"));
        }
        public static IWebElement SignUpDescription(IWebDriver driver)
        {
            return driver.FindElement(By.Id("desc"));
        }
        public static IWebElement SignUpLocation(IWebDriver driver)
        {
            return driver.FindElement(By.Id("location"));
        }
        public static IWebElement SignUpRegisterBtn(IWebDriver driver)
        {
            return driver.FindElement(By.Id("button"));
        }
        public static IWebElement HomeButton(IWebDriver driver)
        {
            return driver.FindElement(By.ClassName("logo"));
        }
        public static IWebElement loginButton(IWebDriver driver)
        {
            return driver.FindElement(By.Id("button"));
        }
        public static IWebElement loginPassword(IWebDriver driver)
        {
            return driver.FindElement(By.Id("password"));
        }
        public static IWebElement loginUsername(IWebDriver driver)
        {
            return driver.FindElement(By.Id("username"));
        }
        public static IWebElement searchButton(IWebDriver driver)
        {
            return driver.FindElement(By.CssSelector("button.btn.btn-outline-light.my-2.my-sm-0[type='submit']"));
        }
        public static IWebElement messageButton(IWebDriver driver)
        {
            return driver.FindElement(By.CssSelector("a[href='DirectMessage.php']"));
        }
        public static IWebElement homeButton(IWebDriver driver)
        {
            return driver.FindElement(By.ClassName("logo"));
        }
        public static IWebElement likeButton(IWebDriver driver)
        {
            return driver.FindElement(By.Name("likeClick"));
        }

        public static IWebElement likeAfter(IWebDriver driver)
        {
            return driver.FindElement(By.Name("unlikeClick"));
        }
        public static IWebElement followButton(IWebDriver driver)
        {
            return driver.FindElement(By.Name("follow"));
        }
        public static IWebElement ContactUsLink(IWebDriver driver)
        {
            return driver.FindElement(By.CssSelector("a[href=contactus]"));
        }
        public static IWebElement locateDropdown(IWebDriver driver)
        {
            return driver.FindElement(By.Id("dropdown01"));
        }
        public static IWebElement logoutButton(IWebDriver driver)
        {
           return driver.FindElement(By.XPath("//a[text()='Logout']"));
        }
    }
}
