﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Bogus;
using System.Security.Cryptography.X509Certificates;
using System.Linq.Expressions;
using OpenQA.Selenium.Interactions;
namespace Final_Project
{
    public class SiteTest
    {
        private static string? Pass = null;
        public static bool UserLogin(IWebDriver driver, string User, string Pass)
        {
            return true;
        }
        public static void UserRegistration(IWebDriver driver, string FName, string LName, string Email, string User)
        {
            try
            {
                //Grabing all registration inputs(text boxes, combo box, and submit button)
                Faker f = new Faker("en_CA");
                IJavaScriptExecutor j = (IJavaScriptExecutor)driver;
                IWebElement txtFName = SiteWebElements.SignUpFName(driver);
                IWebElement txtLName = SiteWebElements.SignUpLName(driver);
                IWebElement txtEmail = SiteWebElements.SignUpEmail(driver);
                IWebElement txtUser = SiteWebElements.SignUpScreenName(driver);
                IWebElement txtPass = SiteWebElements.SignUpPassword(driver);
                IWebElement txtConfPass = SiteWebElements.SignUpConfPass(driver);
                IWebElement txtPhoneNum = SiteWebElements.SignUpPhoneNum(driver);
                IWebElement txtAddress = SiteWebElements.SignUpAddress(driver);
                IWebElement cmbProv = SiteWebElements.SignUpProvince(driver);
                IWebElement txtPostal = SiteWebElements.SignUpPostal(driver);
                IWebElement txtUrl = SiteWebElements.SignUpUrl(driver);
                IWebElement txtDesc = SiteWebElements.SignUpDescription(driver);
                IWebElement txtLocation = SiteWebElements.SignUpLocation(driver);

                //inserting information passed in(First name, last name, etc) as well as generating random information for other inputs
                Pass = f.Internet.Password();
                txtFName.SendKeys(FName);
                txtLName.SendKeys(LName);
                txtEmail.SendKeys(Email);
                txtUser.SendKeys(User);
                txtPass.SendKeys(Pass);
                txtConfPass.SendKeys(Pass);
                txtPhoneNum.SendKeys(f.Phone.PhoneNumber("(###)-###-###"));
                txtAddress.SendKeys(f.Address.StreetAddress());
                j.ExecuteScript("arguments[0].selectedIndex = 5", cmbProv); //uses javascript to change the combobox to index 5(Ontario,ON)
                txtPostal.SendKeys(f.Address.ZipCode("K0A0A#")); //generates small range of ontario postal codes
                txtUrl.SendKeys(f.Internet.Url());
                txtDesc.SendKeys(f.Lorem.Sentence(20));
                txtLocation.SendKeys(f.Address.Longitude().ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Testing if the main login page sign up button works
        public static bool REG01(IWebDriver driver)
        {
            try
            {
                IWebElement button = SiteWebElements.SignUpButton(driver);
                button.Click();
                Thread.Sleep(500);
                if (driver.Url.Contains("http://10.157.123.12/site1/signup.php"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
        //Testing if registration works with valid info
        public static bool REG02(IWebDriver driver)
        {
            try
            {
                UserRegistration(driver, "John", "Dooe", "RMIHALCEA01@mynbcc.ca", "JODO"); //generates info
                IWebElement button = SiteWebElements.SignUpRegisterBtn(driver);
                button.Click();
                Thread.Sleep(500);
                if (driver.SwitchTo().Alert().Text.Contains("NEW TROLL USER ACCEPTED AND INSERTED!")) //checks to see if it is accepted
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
        //Tests to see if registration accepts mismatching password and confirm password(Shouldn't accept it)
        public static bool REG03(IWebDriver driver)
        {
            try
            {
                UserRegistration(driver, "John", "Dooe", "RMIHALCEA01@mynbcc.ca", "JODO");
                IWebElement button = SiteWebElements.SignUpRegisterBtn(driver);
                IWebElement txtPass = SiteWebElements.SignUpPassword(driver);
                IWebElement txtConfPass = SiteWebElements.SignUpConfPass(driver);
                txtPass.Clear();
                txtConfPass.Clear();
                txtPass.SendKeys("pass1234");
                txtConfPass.SendKeys("pass6789");
                button.Click();
                Thread.Sleep(500);
                if (driver.SwitchTo().Alert().Text.Contains("Error: Please check that you've entered and confirmed your password!"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch { return false; }
        }
        //Tests if registration accepts a fake email called "FakeEmail" (shouldn't accept)
        public static bool REG04(IWebDriver driver)
        {
            try
            {
                UserRegistration(driver, "John", "Dooe", "FakeEmail", "JODO"); //passing in fake email
                return TESTREJECTION(driver); //calling test rejection
            }
            catch (Exception)
            {
                return false;
            }
        }
        //Tests if registration accepts invalid phonenumber
        public static bool REG05(IWebDriver driver)
        {
            try
            {
                UserRegistration(driver, "John", "Dooe", "RMIHALCEA01@mynbcc.ca", "JODO");
                IWebElement txtPhoneNum = SiteWebElements.SignUpPhoneNum(driver);
                txtPhoneNum.Clear(); //clears text box
                txtPhoneNum.SendKeys("NotAPhoneNum"); //inserts bad data
                return TESTREJECTION(driver);
            }
            catch (Exception)
            {
                return false;
            }
        }
        //tests if registration accepts invalid address
        public static bool REG06(IWebDriver driver)
        {
            try
            {
                UserRegistration(driver, "John", "Dooe", "RMIHALCEA01@mynbcc.ca", "JODO");
                IWebElement txtAddress = SiteWebElements.SignUpAddress(driver);
                txtAddress.Clear();
                txtAddress.SendKeys("NotAnAddress");
                return TESTREJECTION(driver);

            }
            catch (Exception)
            {
                return false;
            }
        }
        //tests if registration accepts invalid postal code
        public static bool REG07(IWebDriver driver)
        {
            try
            {
                UserRegistration(driver, "John", "Dooe", "RMIHALCEA01@mynbcc.ca", "JODO");
                IWebElement txtPostal = SiteWebElements.SignUpPostal(driver);
                txtPostal.Clear();
                txtPostal.SendKeys("InvalidPostalCode");
                return TESTREJECTION(driver);
            }
            catch (Exception)
            {
                return false;
            }
        }
        //tests if registration accepts a required field to be blank(description)
        public static bool REG08(IWebDriver driver)
        {
            try
            {
                UserRegistration(driver, "John", "Dooe", "RMIHALCEA01@mynbcc.ca", "JODO");
                IWebElement txtDesc = SiteWebElements.SignUpDescription(driver);
                txtDesc.Clear();
                return TESTREJECTION(driver);
            }
            catch (Exception)
            {
                return false;
            }

        }
        //Tests if registration accepts unselected province
        public static bool REG09(IWebDriver driver)
        {
            try
            {
                UserRegistration(driver, "John", "Dooe", "RMIHALCEA01@mynbcc.ca", "JODO");
                IJavaScriptExecutor j = (IJavaScriptExecutor)driver;
                IWebElement cmbProv = SiteWebElements.SignUpProvince(driver);
                j.ExecuteScript("arguments[0].selectedIndex = 0", cmbProv); //sets province to unselected
                return TESTREJECTION(driver);

            }
            catch (Exception)
            {
                return false;
            }
        }
        private static bool TESTREJECTION(IWebDriver driver)
        {
            try
            {
                //grabs the button
                IWebElement button = SiteWebElements.SignUpRegisterBtn(driver);
                button.Click();
                Thread.Sleep(500);

                //checks if the registration goes through, if it does something was not properly rejected
                if (driver.SwitchTo().Alert().Text.Contains("NEW TROLL USER ACCEPTED AND INSERTED!"))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (NoAlertPresentException)
            {
                //if no alert came up when the submit button was pressed and the user is still on the registration page, the info entered to test got rejected
                if (driver.Url.Contains("http://10.157.123.12/site1/signup.php"))
                {
                    return true;
                }
                else { return false; }
            }
            catch (Exception)
            {
                return false;
            }
        }
        //Test the home page button top left
        public static bool REG10(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/signup.php";
                IWebElement homebutton = SiteWebElements.HomeButton(driver);
                homebutton.Click();
                if (driver.Url.Contains("http://10.157.123.12/site1/login.php"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        // tests creating new user and tweeting, but stops at login due to Bug #3 stating invalid screen name despite registration success
        public static bool REG11(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/signup.php";

                UserRegistration(driver, "John", "Dooe", "JJARDINE06@mynbcc.ca", "JODO"); //generate user
                IWebElement button = SiteWebElements.SignUpRegisterBtn(driver);
                button.Click();
                Thread.Sleep(500);
                IAlert alert = driver.SwitchTo().Alert();
                string alertText = alert.Text;
                alert.Accept();
                Thread.Sleep(500);
                //recycling because Id's are the same
                IWebElement username = SiteWebElements.SignUpScreenName(driver);
                IWebElement password = SiteWebElements.SignUpPassword(driver);
                IWebElement loginButton = SiteWebElements.SignUpRegisterBtn(driver);
                username.SendKeys("JODO");
                password.SendKeys(Pass);
                Thread.Sleep(500);
                loginButton.Click();
                if (driver.Url.Contains("http://10.157.123.12/site1/index.php"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (UnhandledAlertException)
            {
                return false;
            }
        }
        public static bool BP01(IWebDriver driver)
        {
            driver.Url = "http://10.157.123.12/site1/login.php";
            IWebElement button = SiteWebElements.loginButton(driver);
            IWebElement password = SiteWebElements.loginPassword(driver);
            IWebElement username = SiteWebElements.loginUsername(driver);

            password.SendKeys("asdf");
            username.SendKeys("nick");
            button.Click();
            Thread.Sleep(1000);
            IWebElement searchbutton = SiteWebElements.searchButton(driver);
            searchbutton.Click();
            if (driver.Url.Contains("http://10.157.123.12/site1/search.php?text="))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //tests if access the direct message page is possible
        public static bool BP02(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("asdf");
                username.SendKeys("nick");
                button.Click();
                Thread.Sleep(1000);
                IWebElement messageButton = SiteWebElements.messageButton(driver);
                Thread.Sleep(1000);
                messageButton.Click();
                Thread.Sleep(1000);
                if (driver.Url.Contains("http://10.157.123.12/site1/DirectMessage.php"))

                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }
        // tests if accessing the direct message page then clicking the logo, returns page to index
        public static bool BP03(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("asdf");
                username.SendKeys("nick");
                button.Click();
                Thread.Sleep(500);
                IWebElement messageButton = SiteWebElements.messageButton(driver);
                Thread.Sleep(500);
                messageButton.Click();
                Thread.Sleep(1000);
                IWebElement homeIcon = SiteWebElements.homeButton(driver);
                Thread.Sleep(1000);
                homeIcon.Click();
                Thread.Sleep(1000);

                if (driver.Url.Contains("http://10.157.123.12/site1/index.php"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        // tests if like button can be interacted with, but it cannot be because there is no unliked variation / BUG #2 
        public static bool BP04(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("asdf");
                username.SendKeys("nick");
                button.Click();
                Thread.Sleep(500);
                IWebElement clickLike = SiteWebElements.likeButton(driver);
                Thread.Sleep(1000);
                clickLike.Click();
                Thread.Sleep(1000);
                IWebElement afterClick = SiteWebElements.likeAfter(driver);
                afterClick.Click();
                Thread.Sleep(1000);
                if (clickLike != afterClick)
                {
                    return true;
                }
                else
                {
                    Thread.Sleep(1000);
                    return false;
                }
            }
            catch (NoSuchElementException ex)
            {
                Console.WriteLine("Element not found!");
                Console.WriteLine(ex);
                Thread.Sleep(2000);
                return false;
            }
            catch (Exception)
            {
                throw;
            }
        }
        // tests if follow button works
        public static bool BP05(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("asdf");
                username.SendKeys("nick");
                button.Click();
                Thread.Sleep(500);
                IWebElement followClick = SiteWebElements.followButton(driver);
                followClick.Click();
                Thread.Sleep(500);
                IAlert alert = driver.SwitchTo().Alert();
                string alertText = alert.Text;

                if (alertText.Contains("You are NOW FOLLOWING"))
                {
                    Thread.Sleep(500);
                    return true;
                }
                else
                {
                    Thread.Sleep(1000);
                    return false;
                }
            }
            catch (NoSuchElementException)
            {
                Console.Write("Element not found!");
                Thread.Sleep(500);
                return false;
            }
            catch (Exception)
            {
                Console.WriteLine($"An error occurred!");
                return false;
            }
        }
        //tests to see if valid login info will work (should pass)
        public static bool LOG01(IWebDriver driver)
        {
            driver.Url = "http://10.157.123.12/site1/login.php";
            IWebElement button = SiteWebElements.loginButton(driver);
            IWebElement password = SiteWebElements.loginPassword(driver);
            IWebElement username = SiteWebElements.loginUsername(driver);

            password.SendKeys("asdf");
            username.SendKeys("nick");
            button.Click();
            Thread.Sleep(1000);
            if (driver.Url.Contains("http://10.157.123.12/site1/index.php?user=1025"))
            {
                driver.Url = "http://10.157.123.12/site1/logout.php";
                return true;
            }
            else
            {
                return false;
            }
        }
        //Tests to see if username left blank will work (Should fail)
        public static bool LOG02(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("asdf");
                username.SendKeys("");
                button.Click();
                Thread.Sleep(1000);
                if (driver.Url == "http://10.157.123.12/site1/index.php")
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }
        //Tests to see if password left blank will work (Should fail)
        public static bool LOG03(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("");
                username.SendKeys("nick");
                button.Click();
                Thread.Sleep(1000);
                if (driver.Url == "http://10.157.123.12/site1/index.php")
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }
        //Tests incorrect password (Should fail)
        public static bool LOG04(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("stinky");
                username.SendKeys("nick");
                button.Click();
                Thread.Sleep(1000);
                if (driver.SwitchTo().Alert().Text.Contains("Incorrect Password. Please Try again!"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (NoAlertPresentException)
            {

                return false;
            }
        }
        //Tests incorrect username (Should fail)
        public static bool LOG05(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("asdf");
                username.SendKeys("shrek");
                button.Click();
                Thread.Sleep(1000);
                if (driver.SwitchTo().Alert().Text.Contains("Incorrect Screen Name. Please Try again!"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (NoAlertPresentException)
            {

                return false;
            }
        }

        //  tests logging in and logging out using the dropdown menu
        public static bool LOG06(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement button = SiteWebElements.loginButton(driver);
                IWebElement password = SiteWebElements.loginPassword(driver);
                IWebElement username = SiteWebElements.loginUsername(driver);

                password.SendKeys("asdf");
                username.SendKeys("nick");
                button.Click();
                Thread.Sleep(1000);

                IWebElement dropdownMenu = SiteWebElements.locateDropdown(driver);
                dropdownMenu.Click();
                Thread.Sleep(1000);
                IWebElement logoutButton = SiteWebElements.logoutButton(driver);
                logoutButton.Click();
                if (driver.Url.Contains("http://10.157.123.12/site1/login.php"))
                {
                    Thread.Sleep(500);
                    return true;
                }
                else
                {
                    Thread.Sleep(500);
                    return false;
                }
            }

            catch (NoSuchElementException)
            {
                Console.Write("LOG06: Element(s) could not be found");
                Thread.Sleep(1000);
                return false;
            }
            catch (NoAlertPresentException)
            {
                Console.Write("LOG06: No Alert present!");
                Thread.Sleep(500);
                throw;
            }
            catch (Exception)
            {
                Console.Write("LOG06: An Exception has occurred! ");
                Thread.Sleep(500);
                throw;
            }
        }
        //Test the contact us link
        public static bool LOG07(IWebDriver driver)
        {
            try
            {
                driver.Url = "http://10.157.123.12/site1/login.php";
                IWebElement contactus = SiteWebElements.ContactUsLink(driver);
                Thread.Sleep(2000);
                contactus.Click();
                Thread.Sleep(1000);
                if (driver.Url.Contains("http://10.157.123.12/site1/contactus"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (NoAlertPresentException)
            {

                return false;
            }
        }
    }
}


